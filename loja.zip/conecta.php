<?php
$conexao = mysqli_connect('localhost', 'simone', '442332si', 'loja');

